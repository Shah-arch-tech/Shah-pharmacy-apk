# Shah Pharmacy Android App

Android-ready project for Shah Pharmacy.

Features carried from the current app: login/logout, admin/staff roles, purchases, daily total sales, expenses, stock, reports, cash, backup/restore, branding and pharmacy animation.

Storage: app data is persisted in a local SQLite database (`shah_pharmacy.db`) through a WebView JavaScript bridge. The web app also keeps a localStorage fallback for browser use.

Build with Android SDK/Gradle:
`./gradlew assembleDebug`

APK output: `app/build/outputs/apk/debug/app-debug.apk`
