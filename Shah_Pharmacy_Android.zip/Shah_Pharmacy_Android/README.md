# Shah Pharmacy Android

Installable Android WebView app for Shah Pharmacy.

## Included
- Shah Pharmacy logo/branding
- Pharmacy photo
- Footer pharmacy animation video
- Admin and Staff login
- Local SQLite persistence through AndroidDB bridge
- Daily sales, purchases, expenses, stock, reports and cash

## Default login
- Admin: `admin` / `1234`
- Staff: `staff` / `1234`

## Build
Use Gradle 8.9 with Java 17 and Android SDK. Build:

`gradle -p Shah_Pharmacy_Android assembleDebug`

Output:

`app/build/outputs/apk/debug/app-debug.apk`

The media assets are intentionally packaged under `app/src/main/assets/assets/`; do not remove them.
