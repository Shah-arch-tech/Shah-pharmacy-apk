package com.shahpharmacy.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.content.ContentValues;

public class MainActivity extends Activity {
    private WebView web;
    private DB db;
    @Override public void onCreate(Bundle b){ super.onCreate(b); db=new DB(this); web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient()); web.addJavascriptInterface(new Bridge(),"AndroidDB"); web.loadUrl("file:///android_asset/index.html"); }
    public class Bridge {
        @JavascriptInterface public String loadDb(){ return db.load(); }
        @JavascriptInterface public void saveDb(String json){ db.save(json); }
    }
    static class DB extends SQLiteOpenHelper {
        DB(Context c){ super(c,"shah_pharmacy.db",null,1); }
        public void onCreate(SQLiteDatabase d){ d.execSQL("CREATE TABLE IF NOT EXISTS app_data (id INTEGER PRIMARY KEY, json TEXT NOT NULL)");
            ContentValues v=new ContentValues(); v.put("id",1); v.put("json", "{\"purchases\":[],\"sales\":[],\"expenses\":[],\"openingCash\":0}"); d.insert("app_data",null,v); }
        public void onUpgrade(SQLiteDatabase d,int o,int n){}
        synchronized String load(){ android.database.Cursor c=getReadableDatabase().query("app_data",new String[]{"json"},"id=1",null,null,null,null); try{ if(c.moveToFirst()) return c.getString(0); return "{\"purchases\":[],\"sales\":[],\"expenses\":[],\"openingCash\":0}";} finally{c.close();} }
        synchronized void save(String json){ ContentValues v=new ContentValues(); v.put("json",json); getWritableDatabase().update("app_data",v,"id=1",null); }
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
